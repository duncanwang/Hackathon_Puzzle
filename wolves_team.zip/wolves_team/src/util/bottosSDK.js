import BottosWalletSDK from 'bottos-sdk-js'

let sdk = new BottosWalletSDK({
  baseUrl: 'http://120.79.187.5:8689/v1'
})

export default sdk
