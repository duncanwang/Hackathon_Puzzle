/**
 * 配置编译环境和线上环境之间的切换
 *
 * url: 接口域名地址
 * routerMode: 路由模式
 */


let url = 'http://puzzle.dingheng.xyz/v1'
let routerMode = 'hash'

export {
  url,
  routerMode
}
