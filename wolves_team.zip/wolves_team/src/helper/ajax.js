import axios from 'axios'
import $q from 'q'
import { $utils } from '@helper'

function requestHandle (params) {
  let defer = $q.defer()
  // console.log('pr===', params)
  axios(params)
    .then(res => {
      // console.log('res------', res)
      if (res.data.code === 1) {
        defer.resolve(res.data)
      } else {
        defer.reject(res.data.msg)
      }
    }).catch(err => {
      console.log('err', err)
      defer.reject(err)
    })

  return defer.promise
}


export default {
  post: function (url, params, op) {
    // console.log(url)
    return requestHandle({
      method: 'post',
      url: url,
      data: params
    })
  },
  get: function (url, params, op) {
    return requestHandle({
      method: 'get',
      url: $utils.queryString(url, params)
    })
  }
}
