import $ajax from '../ajax'
import $utils from '../utils'

let serverUrl = $utils.serverUrl

export default {
  // 登录
  login (data) {
    return $ajax.post(serverUrl('Login/login'), data)
  },
  // 注册
  register (data) {
    return $ajax.post(serverUrl('Login/register'), data)
  },
  // 忘记密码
  reset (data) {
    return $ajax.post(serverUrl('Login/forpwd'), data)
  },
  // 发送验证码
  SendMobile (data) {
    return $ajax.post(serverUrl('Login/SendMobile'), data)
  },
  // 获取交易记录
  tradelist (data) {
    return $ajax.get(serverUrl('User/tradelist'), data)
  },
  // 我的藏品
  mycollection (data) {
    return $ajax.get(serverUrl('User/mycollection'), data)
  },
  // 作品碎片
  debriscomplete (data) {
    return $ajax.get(serverUrl('Works/debriscomplete'), data)
  },
  // 获取排行榜
  rankinglist (data) {
    return $ajax.get(serverUrl('Works/rankinglist'), data)
  },
  // 作品详情
  OtherDetail (data) {
    return $ajax.get(serverUrl('Works/OtherDetail'), data)
  },
  purchasedebris (data) {
    return $ajax.post(serverUrl('Works/purchasedebris'), data)
  },
  // 奖池分配
  poolallocation (data) {
    return $ajax.get(serverUrl('Works/poolallocation'), data)
  },
  // 配置中心
  gameconfig (data) {
    return $ajax.get(serverUrl('other/gameconfig'), data)
  },
  // 发送交易记录
  WorksTradingAdd (data) {
    return $ajax.post(serverUrl('Works/WorksTradingAdd'), data)
  },
  // 首发购买情况
  WorksDebrisFirst (data) {
    return $ajax.post(serverUrl('Works/WorksDebrisFirst'), data)
  }
}
