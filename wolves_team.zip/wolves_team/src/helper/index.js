export const $ajax = require('./ajax').default
export const $apis = require('./apis').default
export const $auth = require('./auth').default
export const $utils = require('./utils').default
export const $lodash = require('./lodash').default
export const $document = require('./document').default
