// Vuex Storage Key
export const STORAGE_KEY = 'vuex-storage'
