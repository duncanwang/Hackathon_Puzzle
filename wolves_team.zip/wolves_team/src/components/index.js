import globalComponents from '@components/_global'

export const globalComponentsRegister = function () {
  globalComponents.register()
}
