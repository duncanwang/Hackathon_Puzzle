module.exports = require('./Icon.vue')
