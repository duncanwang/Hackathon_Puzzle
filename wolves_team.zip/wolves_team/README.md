npm install (npm i / yarn)
npm start / npm run dev / yarn run dev
```

Go to http://localhost:8080/. If port 8080 is already in use on your machine, **the program will specify the available port (incremental) for you, for example, `8081` / `8082` ...**. Of course, you can temporarily replace the port using the following command:

```
PORT=8888 npm run dev
```